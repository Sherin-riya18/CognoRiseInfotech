import Des2 from './Des2';

export default { Des2 };
