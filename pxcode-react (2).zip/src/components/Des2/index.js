import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Des2(props) {
  return (
    <div className={cn(styles.root, props.className, 'des2')}>
      <div className={styles.content_box}>
        <img className={styles.image} src={'/assets/801008693ed05e43724ce601dbcb6430.png'} alt="alt text" />
        <h5 className={styles.highlight}>        Renee Olson</h5>
        <img className={styles.image1} src={'/assets/c200ed8b98a15e6bd6ccd07812ce1f31.png'} alt="alt text" />
        <div className={styles.rect7} />
        <img className={styles.image7} src={'/assets/988a48c399d70577a9d9af373aad4c23.png'} alt="alt text" />
        <img className={styles.image8} src={'/assets/4a4683b77e9d810750f8fc281e113653.png'} alt="alt text" />
        <img className={styles.image9} src={'/assets/3671c2793b22925199ce56cfeeb6deda.png'} alt="alt text" />
        <img className={styles.image10} src={'/assets/250927d5e0b15d7f01c970c53767e589.png'} alt="alt text" />
        <img className={styles.image11} src={'/assets/2952e9b050a0cab461cb1ca5ee35c764.png'} alt="alt text" />
        <img className={styles.image12} src={'/assets/4fc12f29e532dff431850401979ece09.png'} alt="alt text" />
        <img className={styles.image13} src={'/assets/d34ff616d22b3285e93c5cf6fcd18156.png'} alt="alt text" />
      </div>
    </div>
  );
}

Des2.propTypes = {
  className: PropTypes.string
};

export default Des2;
