import Design3h from './Design3h';

export default { Design3h };
