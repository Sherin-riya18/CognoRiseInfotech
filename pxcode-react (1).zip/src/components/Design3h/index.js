import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Design3h(props) {
  return (
    <div className={cn(styles.root, props.className, 'design3h')}>
      <div className={styles.group}>
        <div className={styles.content_box1}>
          <img className={styles.image} src={'/assets/red_abstract_architecture.png'} alt="alt text" />

          <div className={styles.content_box}>
            <h1 className={styles.hero_title}>Modern Business Brochure</h1>
          </div>

          <div className={styles.group1}>
            <div className={styles.content_box2}>
              <div className={styles.text}>ADDRESS LINE 1</div>
            </div>

            <div className={styles.flex_col}>
              <img className={styles.image1} src={'/assets/31df2ff6ec694c3647f04180c598618f.png'} alt="alt text" />
              <p className={styles.text1}>
                ADDRESS LINE 2<br />
              </p>
            </div>
          </div>
        </div>

        <div className={styles.group2}>
          <p className={styles.paragraph}>
            Ab Street,Mumbai
            <br />
            (123)-345-4566
            <br />
            www.tech.com
            <br />
            office@tech.com
          </p>
          <p className={styles.paragraph1}>
            JK Street,Mumbai
            <br />
            (123)-754-9373
            <br />
            www.techile.com
            <br />
            office@techile.com
          </p>
        </div>
      </div>
    </div>
  );
}

Design3h.propTypes = {
  className: PropTypes.string
};

export default Design3h;
