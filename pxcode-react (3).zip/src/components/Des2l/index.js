import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Des2l(props) {
  return (
    <div className={cn(styles.root, props.className, 'des2l')}>
      <img className={styles.image2} src={'/assets/car_dashboard_symbol.png'} alt="alt text" />

      <div className={styles.content_box}>
        <div className={styles.group}>
          <div className={styles.content_box3}>
            <div className={styles.rect} />
            <img className={styles.image} src={'/assets/weekly_calendar_icons.png'} alt="alt text" />
            <img className={styles.image1} src={'/assets/stylized_right_arrow.png'} alt="alt text" />
            <h2 className={styles.medium_title}>April</h2>
            <h5 className={styles.highlight}>Wednesday,18 Apr 2022</h5>
          </div>

          <div className={styles.rect7} />
        </div>

        <div className={styles.info}>
          1.800 cal
          <br />
          Yesterday,00:05
        </div>
        <div className={styles.info1}>
          1.800 cal
          <br />
          Yesterday,00:05
        </div>
        <p className={styles.info2}>
          12 hrs
          <br />
          Yesterday,00:05
        </p>
        <div className={styles.info3}>
          2.2 km
          <br />
          Yesterday,00:05
        </div>
        <div className={styles.info4}>
          3.345 steps
          <br />
          Yesterday,00:05
        </div>
        <div className={styles.rect6} />
        <div className={styles.rect61} />
        <div className={styles.rect9} />
      </div>
    </div>
  );
}

Des2l.propTypes = {
  className: PropTypes.string
};

export default Des2l;
