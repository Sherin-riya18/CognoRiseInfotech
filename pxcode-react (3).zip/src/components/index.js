import Des2l from './Des2l';

export default { Des2l };
