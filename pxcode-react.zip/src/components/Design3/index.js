import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Design3(props) {
  return (
    <div className={cn(styles.root, props.className, 'design3')}>
      <div className={styles.group}>
        <img className={styles.image} src={'/assets/red_abstract_building.png'} alt="alt text" />

        <div className={styles.flex_col}>
          <h5 className={styles.highlight}>CONTACT</h5>
          <h5 className={styles.highlight1}>TECHLANCE</h5>
          <h5 className={styles.highlight2}>SR STREET , MUMBAI</h5>
          <h5 className={styles.highlight21}>(123)-345 7890</h5>
          <h5 className={styles.highlight3}>www.techlance.com</h5>
          <h5 className={styles.highlight31}>office@techlance.com</h5>
        </div>
      </div>

      <img className={styles.image1} src={'/assets/4dc9c178da0b3e643c3e000c6cc1c07e.png'} alt="alt text" />
    </div>
  );
}

Design3.propTypes = {
  className: PropTypes.string
};

export default Design3;
