import Design3 from './Design3';

export default { Design3 };
