import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import styles from './index.module.scss';

function Cd(props) {
  return (
    <div className={cn(styles.root, props.className, 'cd')}>
      <img className={styles.image5} src={'/assets/12989c0204f956fd652c6195d6309a7c.png'} alt="alt text" />
      <h2 className={styles.medium_title}>+00 123 456 789</h2>
      <img className={styles.decorator} src={'/assets/02cbba021fa2860e7f2c86e7ae16bb08.png'} alt="alt text" />
      <h1 className={styles.title}>info@gmail.com</h1>

      <div className={styles.group}>
        <div className={styles.content_box}>
          <div className={styles.group1}>
            <img className={styles.image} src={'/assets/solid_black_star.png'} alt="alt text" />

            <div className={styles.content_box1}>
              <img className={styles.image3} src={'/assets/ce9b77f7a0d46a031c4d499317695700.png'} alt="alt text" />
              <div className={styles.rect} />
              <img className={styles.image7} src={'/assets/f6dab43883b01f726e1247572a908153.png'} alt="alt text" />
              <img className={styles.image8} src={'/assets/black_diagonal_rectangle.png'} alt="alt text" />
              <img className={styles.image9} src={'/assets/gold_horizontal_lines.png'} alt="alt text" />
              <h3 className={styles.subtitle}>GRAPHIC DESIGNER</h3>
              <img className={styles.image10} src={'/assets/gold_horizontal_line.png'} alt="alt text" />
            </div>
          </div>

          <img className={styles.image1} src={'/assets/774cdd6e903512395810c1b184fc07f7.png'} alt="alt text" />
          <img className={styles.image2} src={'/assets/11f8bb211aee4671092cd246339df983.png'} alt="alt text" />
          <img className={styles.image4} src={'/assets/5ef249f5969fcf5c45ae28c1c7c99cec.png'} alt="alt text" />
          <img className={styles.image6} src={'/assets/3715b13f06162fee23e78753cd486239.png'} alt="alt text" />
          <h1 className={styles.big_title}>SHERIN</h1>
          <img className={styles.image11} src={'/assets/simple_black_check.png'} alt="alt text" />
          <img className={styles.image12} src={'/assets/black_and_white_eye_shape.png'} alt="alt text" />
          <h1 className={styles.title1}>ABC COLONY </h1>
          <img className={styles.image13} src={'/assets/black_letter_m.png'} alt="alt text" />
          <img className={styles.image14} src={'/assets/black_and_white_geometric_pattern.png'} alt="alt text" />
        </div>

        <div className={styles.rect1} />
      </div>
    </div>
  );
}

Cd.propTypes = {
  className: PropTypes.string
};

export default Cd;
