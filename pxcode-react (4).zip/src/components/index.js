import Cd from './Cd';

export default { Cd };
